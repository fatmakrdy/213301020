package com.example.bilet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
