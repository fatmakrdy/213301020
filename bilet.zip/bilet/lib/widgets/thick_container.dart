import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ThickContaner extends StatelessWidget {
  const ThickContaner({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(3.0),
      decoration: BoxDecoration(
        border: Border.all(width:2.5,color: Colors.white )
      ),
    );
  }
}
