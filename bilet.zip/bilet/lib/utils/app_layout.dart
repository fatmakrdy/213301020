import 'package:flutter/cupertino.dart';

class AppLayout{
  static getsize(BuildContext context){
    return MediaQuery.of(context).size.width;
  }
}